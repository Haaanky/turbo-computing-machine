```markdown
# Design System Specification: The Bioluminescent Void

## 1. Overview & Creative North Star: "The Living Nebula"
This design system rejects the industrial rigidity of the modern web. We are moving away from the "containerized" internet of boxes and borders, moving instead toward a **Cyber-Organic** reality. 

**The Creative North Star: The Living Nebula.** 
The UI is not a static interface; it is a sentient, bioluminescent organism suspended in a shifting deep-space void. Elements should feel like liquid mercury or plasma—merging, breathing, and reacting to user proximity. We achieve this through "Metaball" logic: when two elements approach, they should visually "stretch" toward each other rather than remaining isolated units. Hierarchy is not dictated by grids, but by luminosity and fluid motion.

---

## 2. Colors: The Shifting Void
Our palette is rooted in the contrast between the absolute obsidian of the "void" and the electric radiation of bioluminescence.

### The "No-Line" Rule
**Borders are forbidden.** You are prohibited from using 1px solid strokes to define space. Boundaries must be felt, not seen. Use `surface-container` tiers to create soft, "puddle-like" areas of focus.
- **Surface Nesting:** Use `surface-container-lowest` (#000000) for the deepest background layers. As elements become more interactive or "active," shift upward through `surface-container-low` (#17101e) to `surface-bright` (#32283c).
- **The Glow Logic:** Instead of an outline, use a 4px to 12px outer blur of `secondary` (#00fbfb) or `tertiary` (#bcff5f) at 20% opacity to indicate focus.

### Palette Roles
- **Background (`#120c18`):** The primary void.
- **Primary (`#ada3ff`):** Electric Indigo. Used for the "core" of interactive organisms.
- **Secondary (`#00fbfb`):** Cyan Glow. Used for secondary navigation pulses and "active" states.
- **Tertiary (`#bcff5f`):** Acid Green. Reserved for "Action" triggers and success states—it should feel like a sudden chemical reaction.
- **The "Glass & Gradient" Rule:** Use linear gradients from `primary` (#ada3ff) to `primary-dim` (#7058ff) with a `backdrop-filter: blur(20px)` to create a liquid, translucent feel.

---

## 3. Typography: Breathing Variable Forms
Typography must feel as though it is vibrating with energy. We utilize variable fonts to simulate "breath."

- **Display (Spline Sans):** Our headline voice. Use `display-lg` (3.5rem) for high-impact spatial discovery. Use variable axes to slightly increase "weight" or "slant" on hover, as if the text is leaning toward the cursor.
- **Body (Be Vietnam Pro):** Our functional voice. Legibility is key amidst the chaos. Keep `body-lg` (1rem) clean but set it against `on-surface` (#f4e7f9) to ensure high contrast against the dark void.
- **Labels (Space Grotesk):** Monospaced, technical, "cyber" feel. Used for coordinates, timestamps, or metadata.

*Director's Note:* Treat text as an integrated part of the nebula. Text should never feel "placed on top" of a box; use `mix-blend-mode: screen` or `lighten` to let the background gradients bleed into the letterforms.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are too "earthly" for this system. We use **Ambient Radiance.**

- **The Layering Principle:** Depth is achieved by stacking `surface-container` tiers. A "Card" is simply a `surface-container-high` (#251c2d) blob with a `DEFAULT` (1rem) or `xl` (3rem) corner radius (effectively a pill or circle) floating over the `surface` (#120c18).
- **Glassmorphism:** All floating UI must use `surface-tint` (#ada3ff) at 5-10% opacity with a heavy `backdrop-filter: blur(40px)`. This creates the "liquid mercury" effect where the background colors warp behind the element.
- **The Ghost Border:** If an edge must be defined for accessibility, use `outline-variant` (#4d4553) at 15% opacity. It should be nearly invisible until the eye seeks it out.

---

## 5. Components: Fluid Entities

### Buttons (Plasma Triggers)
- **Primary:** No hard corners. Use `rounded-full` (9999px). Background is a gradient of `primary` to `secondary`. On hover, the element should expand slightly (Scale 1.05) and increase its outer blur (glow).
- **Secondary:** Transparent background with a `secondary` (#00fbfb) "Ghost Border" at 20% opacity.

### Navigation (Spatial Discovery)
Reject the top-bar header. Use a **Radial Hub** or **Draggable Nebula**. Navigation items should be floating "nodes" (`surface-container-highest`) that gravitate toward the center of the viewport.

### Input Fields (Liquid Portals)
- **Text Inputs:** Use `surface-container-lowest` (#000000) with a bottom-heavy gradient glow of `primary`. When focused, the glow should "pulse" like a heartbeat using a CSS keyframe animation.
- **No Dividers:** In lists, never use a line. Use `spacing-4` (1.4rem) of vertical "void" or a subtle shift to `surface-container-low` to separate items.

### Metaball Chips
- Use `tertiary` (#bcff5f) for active filter chips. When two chips are adjacent, their background blurs should overlap to create a single, continuous organic shape.

---

## 6. Do’s and Don'ts

### Do:
- **Use Intentional Asymmetry:** Align elements to a flow, not a grid. Let elements "float" at slightly different Y-axis offsets.
- **Animate Transitions:** Every state change must be fluid (use `cubic-bezier(0.4, 0, 0.2, 1)`).
- **Embrace the Blur:** Use heavy blurs to define the edges of "glow zones."

### Don't:
- **No Right Angles:** If a corner is 90 degrees, the design is broken. Minimum radius is `md` (1.5rem), but `xl` (3rem) is preferred.
- **No Opaque Solids:** Purely solid, flat colors look "dead." Always inject a 5% gradient or a subtle transparency.
- **No Standard Shadows:** Do not use `rgba(0,0,0,0.5)`. Use a tinted glow based on the element's primary color (e.g., an Indigo glow for an Indigo button).

---

## 7. Spacing & Scale
Spacing is not about alignment; it is about **Pressure.** 
- Use `spacing-16` (5.5rem) to create "Great Voids"—massive gaps that force the user to focus on a single bioluminescent element.
- Use `spacing-2` (0.7rem) for "Clustered Organisms"—grouping related data into a single liquid mass.

*Final Director's Note: You are not building a website; you are culturing a digital ecosystem. If it feels static, it is wrong. If it feels "boxed in," break it.*```